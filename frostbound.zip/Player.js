/* The explorer: movement, stamina and the five survival meters. */
class Player extends Entity {
  constructor(warmth = 60, hunger = 60, thirst = 60) {
    super(80, 440);
    this.hp = 100; this.stamina = 100; this.warmth = warmth; this.hunger = hunger; this.thirst = thirst;
    this.inv = new Inventory(); this.hurt = 0; this.sprintTime = 0;
    this.attackCd = new Cooldown(CFG.ATTACK_COOLDOWN); this.gatherCd = new Cooldown(CFG.GATHER_COOLDOWN);
  }
  get armor() { return this.inv.gear.coat ? 3 : 0; }
  get weaponDamage() { return this.inv.gear.spear ? 10 : 3; }
  update(dt, k, nearFire, storm) {
    const dx = (k.d || k.arrowright ? 1 : 0) - (k.a || k.arrowleft ? 1 : 0);
    const dy = (k.s || k.arrowdown ? 1 : 0) - (k.w || k.arrowup ? 1 : 0);
    const moving = dx || dy, sprint = moving && k.shift && this.stamina > 3;
    if (moving) {
      const l = Math.hypot(dx, dy), v = sprint ? 150 : 90;
      this.x = clamp(this.x + dx / l * v * dt, 14, CFG.W - 14); this.y = clamp(this.y + dy / l * v * dt, 14, CFG.H - 14);
    }
    if (sprint) { this.stamina -= 18 * dt; this.sprintTime += dt; } else this.stamina += 12 * dt;
    this.stamina = clamp(this.stamina, 0, 100);
    const cold = (this.inv.gear.coat ? 0.8 : 1.5) * (storm ? 2 : 1);
    this.warmth = clamp(this.warmth + (nearFire ? 8 : -cold) * dt, 0, 100);
    this.hunger = clamp(this.hunger - 0.7 * dt, 0, 100);
    this.thirst = clamp(this.thirst - 1 * dt, 0, 100);
    if (this.warmth <= 0 || this.hunger <= 0 || this.thirst <= 0) this.hp -= 3 * dt;
    else if (this.warmth > 50 && this.hunger > 50 && this.thirst > 50) this.hp = Math.min(100, this.hp + dt);
    this.hurt = Math.max(0, this.hurt - dt);
  }
}
