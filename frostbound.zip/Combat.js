/* Combat rules. Fixes B3 (minimum damage and attack cooldown). */
class Combat {
  static damage(weapon, armor) { return Math.max(1, weapon - armor); }
}
class Cooldown {
  constructor(seconds) { this.seconds = seconds; this.last = -Infinity; }
  ready(now) { return now - this.last >= this.seconds - 1e-9; }
  trigger(now) { this.last = now; }
}
