/* Test suite: runs the same 10 cases on v0.1 (buggy, kept for comparison) and v0.2 (the real classes). */
class QA {
  static v01() {
    const first = k => Object.keys(CFG.RECIPES[k].cost)[0];
    return {
      gather: (i, r, n) => ({ ...i, [r]: (i[r] || 0) + n }),                       // B1: no cap
      craft: (i, k) => { const f = first(k), n = CFG.RECIPES[k].cost[f]; return (i[f] || 0) < n ? { ok: false, items: i } : { ok: true, items: { ...i, [f]: i[f] - n } }; }, // B2: first ingredient only
      hit: (w, a) => w - a,                                                         // B3: no floor
      hits: () => QA.simulate(new Cooldown(0))                                     // B3: no cooldown
    };
  }
  static v02() {
    const make = items => { const inv = new Inventory(); inv.items = { ...items }; return inv; };
    return {
      gather: (i, r, n) => { const inv = make(i); inv.add(r, n); return inv.items; },
      craft: (i, k) => { const inv = make(i), res = inv.craft(k); return { ok: res.ok, items: inv.items }; },
      hit: (w, a) => Combat.damage(w, a),
      hits: () => QA.simulate(new Cooldown(CFG.ATTACK_COOLDOWN))
    };
  }
  static simulate(cd) { let n = 0; for (let t = 0; t < 1; t += 1 / 60) if (cd.ready(t)) { cd.trigger(t); n++; } return n; }
  static fmt(r) { return (r.ok ? 'crafted' : 'blocked') + ' w' + (r.items.wood || 0) + ' s' + (r.items.stone || 0); }
  static tests() {
    const f = QA.fmt;
    return [
      ['T1', 'Gather 2 wood, empty pack', 'wood = 2', I => I.gather({}, 'wood', 2).wood, v => v === 2],
      ['T2', 'Gather 3 stone with 9 in pack (cap 10)', 'stone = 10', I => I.gather({ stone: 9 }, 'stone', 3).stone, v => v === 10],
      ['T3', 'Gather berries with a full stack (10)', 'stays 10', I => I.gather({ berries: 10 }, 'berries', 1).berries, v => v === 10],
      ['T4', 'Craft spear: 2 wood, 0 stone', 'blocked w2 s0', I => f(I.craft({ wood: 2, stone: 0 }, 'spear')), v => v === 'blocked w2 s0'],
      ['T5', 'Craft spear: 2 wood, 2 stone', 'crafted w0 s0', I => f(I.craft({ wood: 2, stone: 2 }, 'spear')), v => v === 'crafted w0 s0'],
      ['T6', 'Craft fur coat: 1 hide (needs 2)', 'blocked', I => I.craft({ hide: 1 }, 'coat').ok ? 'crafted' : 'blocked', v => v === 'blocked'],
      ['T7', 'Spear (10) vs wolf armor 4', '6 damage', I => I.hit(10, 4), v => v === 6],
      ['T8', 'Bare fists (3) vs wolf armor 4', '1 damage (never heals)', I => I.hit(3, 4), v => v === 1],
      ['T9', 'Weak bite (2) vs fur coat armor 3', '1 damage (never heals)', I => I.hit(2, 3), v => v === 1],
      ['T10', 'Hold Space for 1 second', '3 hits or fewer', I => I.hits(), v => v <= 3]
    ];
  }
  static run(table, summary) {
    const A = QA.v01(), B = QA.v02(); let a = 0, b = 0;
    let h = '<tr><th>ID</th><th>Scenario</th><th>Expected</th><th>v0.1 actual</th><th>v0.1</th><th>v0.2 actual</th><th>v0.2</th></tr>';
    for (const [id, s, e, f, ok] of QA.tests()) {
      const r0 = f(A), r1 = f(B), p0 = ok(r0), p1 = ok(r1); a += p0; b += p1;
      h += `<tr><td>${id}</td><td>${s}</td><td>${e}</td><td>${r0}</td><td class="${p0 ? 'p' : 'f'}">${p0 ? 'PASS' : 'FAIL'}</td><td>${r1}</td><td class="${p1 ? 'p' : 'f'}">${p1 ? 'PASS' : 'FAIL'}</td></tr>`;
    }
    table.innerHTML = h; summary.textContent = `v0.1: ${a}/10 passed · v0.2: ${b}/10 passed`;
  }
}
