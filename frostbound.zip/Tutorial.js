/* Ten-step tutorial, ordered from basic to advanced. Each step: instruction, target ring, done-check, highlighted button. */
class Tutorial {
  constructor(game) {
    const g = game, first = k => g.res.find(r => r.kind === k);
    this.g = g; this.i = 0; this.t = 0;
    this.steps = [
      { title: 'Walk', text: 'Use WASD or arrow keys to walk to the glowing tree.', target: () => first('tree'), done: () => g.p.dist(first('tree')) < 38, hl: () => '' },
      { title: 'Gather wood', text: 'Stand next to the tree and press E repeatedly. Collect 4 wood. Each gather costs a little stamina.', target: () => first('tree'), done: () => g.p.inv.count('wood') >= 4, hl: () => '' },
      { title: 'Gather stone', text: 'Walk to the grey rock and press E. Collect 3 stone.', target: () => first('rock'), done: () => g.p.inv.count('stone') >= 3, hl: () => '' },
      { title: 'Build a campfire', text: 'Press Campfire in the Craft panel (4 wood + 1 stone). The fire is placed where you stand.', target: () => null, done: () => g.fires.length > 0, hl: () => 'fire' },
      { title: 'Stay warm', text: 'Warmth drains outside. Stand within the orange glow until Warmth reaches 85.', target: () => g.fires[0], done: () => g.p.warmth >= 85 && g.fires.some(f => g.p.dist(f) < 90), hl: () => '' },
      { title: 'Eat and drink', text: 'Pick berries at a bush and chip ice (E), then use Eat and Melt ice (or Q and R).',
        target: () => (!g.p.inv.count('berries') && !g.ate) ? first('bush') : (!g.p.inv.count('ice') && !g.drank) ? first('ice') : null,
        done: () => g.ate && g.drank, hl: () => g.ate ? 'drink' : 'eat' },
      { title: 'Sprint', text: 'Hold Shift while moving for 2 seconds. Watch the blue Stamina bar; it refills when you slow down.', target: () => null, done: () => g.p.sprintTime >= 2, hl: () => '' },
      { title: 'Craft a spear', text: 'Spear costs 2 wood + 2 stone. Gather what is missing, then craft it.', target: () => null, done: () => g.p.inv.gear.spear, hl: () => 'spear' },
      { title: 'Fight the dummy', text: 'Stand next to the dummy and hold Space. Attacks have a 0.4 s cooldown. The spear hits for 10.', target: () => g.dummy, done: () => g.dummy.hp <= 0, hl: () => '' },
      { title: 'Your mission', text: 'Wolves drop hide. Get 1 hide, craft a Signal flare, reach the beacon (top right) and press E. A fur coat (2 hide) cuts bite damage and cold.', target: () => CFG.BEACON, done: () => this.t > 8, hl: () => 'flare' }
    ];
  }
  get step() { return this.steps[this.i]; }
  update(dt) {
    this.t += dt;
    if (this.step.done()) {
      this.g.toast('✔ ' + this.step.title + ' complete');
      this.i++; this.t = 0;
      if (this.i >= this.steps.length) this.g.finishTutorial();
    }
  }
}
