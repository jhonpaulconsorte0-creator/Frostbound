/* Item storage and crafting. Fixes B1 (stack cap) and B2 (full ingredient check). */
class Inventory {
  constructor(cap = CFG.CAP) { this.cap = cap; this.items = {}; this.gear = {}; }
  count(r) { return this.items[r] || 0; }
  /** Adds up to n items, never above the cap. Returns how many were really added. */
  add(r, n) {
    const added = Math.max(0, Math.min(n, this.cap - this.count(r)));
    this.items[r] = this.count(r) + added;
    return added;
  }
  use(r) { if (this.count(r) < 1) return false; this.items[r]--; return true; }
  missing(cost) {
    return Object.entries(cost).filter(([r, n]) => this.count(r) < n).map(([r, n]) => [r, n - this.count(r)]);
  }
  /** Checks EVERY ingredient first, then spends them all together. */
  craft(key) {
    const cost = CFG.RECIPES[key].cost, missing = this.missing(cost);
    if (missing.length) return { ok: false, missing };
    for (const r in cost) this.items[r] -= cost[r];
    return { ok: true, missing: [] };
  }
}
