/* Shared constants, recipes and helpers. */
const CFG = {
  W: 768, H: 512, CAP: 10, REACH: 40, BITE: 8,
  ATTACK_COOLDOWN: 0.4, GATHER_COOLDOWN: 0.35,
  WOLF: { hp: 30, armor: 4 },
  BEACON: { x: 720, y: 50 },
  YIELD: { tree: 'wood', rock: 'stone', bush: 'berries', ice: 'ice' },
  RECIPES: {
    fire:  { name: 'Campfire',     cost: { wood: 4, stone: 1 } },
    spear: { name: 'Spear',        cost: { wood: 2, stone: 2 } },
    coat:  { name: 'Fur coat',     cost: { hide: 2 } },
    flare: { name: 'Signal flare', cost: { wood: 2, stone: 2, hide: 1 } }
  }
};
const METERS = [['hp', 'Health', '#e0525a'], ['stamina', 'Stamina', '#3fa7d6'], ['warmth', 'Warmth', '#ff8a4c'], ['hunger', 'Hunger', '#c99a3b'], ['thirst', 'Thirst', '#6cc8e8']];
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
