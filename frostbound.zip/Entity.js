/* World objects: Entity base class, Resource nodes, Wolf enemy, Dummy target. */
class Entity {
  constructor(x, y) { this.x = x; this.y = y; }
  dist(o) { return Math.hypot(this.x - o.x, this.y - o.y); }
}
class Resource extends Entity {
  constructor(kind, x, y, left) { super(x, y); this.kind = kind; this.left = left; this.item = CFG.YIELD[kind]; }
}
class Wolf extends Entity {
  constructor(x, y) {
    super(x, y);
    this.hp = CFG.WOLF.hp; this.armor = CFG.WOLF.armor; this.isWolf = true; this.biteTimer = 0; this.flash = 0;
  }
  update(dt, player, game) {
    const d = this.dist(player);
    if (d < 170 && d > 20) { this.x += (player.x - this.x) / d * 70 * dt; this.y += (player.y - this.y) / d * 70 * dt; }
    this.biteTimer -= dt; this.flash = Math.max(0, this.flash - dt);
    if (d <= 24 && this.biteTimer <= 0) { this.biteTimer = 1; game.hurtPlayer(Combat.damage(CFG.BITE, player.armor)); }
  }
}
class Dummy extends Entity {
  constructor(x, y) { super(x, y); this.hp = 12; this.armor = 0; this.flash = 0; }
}
