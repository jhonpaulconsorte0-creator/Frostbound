/* Draws the world on the canvas in a blocky pixel-art style. */
class Renderer {
  constructor(ctx) {
    this.x = ctx;
    this.flakes = [...Array(70)].map(() => ({ x: Math.random() * CFG.W, y: Math.random() * CFG.H, s: 20 + Math.random() * 30 }));
  }
  draw(g, t) {
    const x = this.x, W = CFG.W, H = CFG.H, B = CFG.BEACON, s = g.p;
    const R = (a, b, w, h, c) => { x.fillStyle = c; x.fillRect(Math.round(a / 4) * 4, Math.round(b / 4) * 4, w, h); };
    const L = (q, a, b, c) => { x.fillStyle = '#000'; x.fillText(q, a + 1, b + 1); x.fillStyle = c || '#fff'; x.fillText(q, a, b); };
    for (let i = 0; i < W; i += 32) for (let j = 0; j < H; j += 32) { x.fillStyle = ((i + j) / 32) % 2 ? '#8aa3d4' : '#7f98c9'; x.fillRect(i, j, 32, 32); }
    x.font = 'bold 14px "Courier New",monospace'; x.textAlign = 'center';
    const target = g.tut ? g.tut.step.target() : null;
    for (const e of g.res) {
      x.globalAlpha = e.left > 0 ? 1 : .35;
      if (e.kind === 'tree') { R(e.x - 4, e.y + 4, 8, 8, '#6b4423'); R(e.x - 16, e.y - 4, 32, 10, '#14543a'); R(e.x - 12, e.y - 12, 24, 10, '#1d7a52'); R(e.x - 8, e.y - 20, 16, 10, '#2fa36b'); R(e.x - 4, e.y - 24, 8, 4, '#fff'); }
      else if (e.kind === 'rock') { R(e.x - 12, e.y - 4, 24, 12, '#5d6878'); R(e.x - 8, e.y - 10, 16, 8, '#aab4c4'); }
      else if (e.kind === 'bush') { R(e.x - 12, e.y - 8, 24, 16, '#2f8f4e'); [[-8, -4], [4, 0], [-2, 4]].forEach(q => R(e.x + q[0], e.y + q[1], 4, 4, '#ff4d6d')); }
      else { R(e.x - 8, e.y - 8, 16, 16, '#bff0ff'); R(e.x - 4, e.y - 12, 8, 4, '#fff'); }
      x.globalAlpha = 1;
    }
    R(B.x - 4, B.y - 8, 8, 32, '#e2e8f0'); R(B.x - 8, B.y - 20, 16, 12, Math.sin(t / 300) > 0 ? '#ff3d3d' : '#7a1f2a'); L('Rescue beacon', B.x - 14, B.y + 40);
    for (const f of g.fires) {
      x.globalAlpha = .16; x.fillStyle = '#ffb347'; x.fillRect(f.x - 90, f.y - 90, 180, 180); x.globalAlpha = 1;
      R(f.x - 8, f.y - 4, 16, 12, '#ff7a1f'); R(f.x - 4, f.y - 12 - (Math.sin(t / 120) > 0 ? 4 : 0), 8, 12, '#ffd23f');
    }
    if (g.dummy) {
      const d = g.dummy; R(d.x - 4, d.y - 16, 8, 28, d.hp > 0 ? '#d6a45f' : '#7a6544');
      if (d.hp > 0) R(d.x - 12, d.y - 8, 24, 6, '#d6a45f');
      L(d.hp > 0 ? 'Training dummy ' + d.hp + '/12' : 'Dummy down', d.x, d.y - 24);
    }
    for (const w of g.wolves) {
      const c = w.flash > 0 ? '#fff' : '#c9d1da';
      R(w.x - 12, w.y - 6, 24, 12, c); R(w.x + 8, w.y - 10, 8, 8, c); R(w.x + 12, w.y - 8, 4, 4, '#ffd23f'); R(w.x - 16, w.y - 2, 4, 4, c);
      R(w.x - 14, w.y - 20, 28, 4, '#000'); R(w.x - 14, w.y - 20, 28 * w.hp / CFG.WOLF.hp, 4, '#ff4d6d');
    }
    if (target) {
      const q = 28 + Math.round(Math.sin(t / 200) * 2) * 2;
      x.strokeStyle = '#ffb347'; x.lineWidth = 4; x.strokeRect(Math.round((target.x - q) / 4) * 4, Math.round((target.y - q) / 4) * 4, q * 2, q * 2);
    }
    R(s.x - 8, s.y - 8, 16, 16, s.hurt > 0 ? '#ff4d6d' : s.inv.gear.coat ? '#8a4b1f' : '#ff7a1f'); R(s.x - 4, s.y - 8, 8, 6, '#f6d5b8');
    x.font = 'bold 15px "Courier New",monospace';
    g.fx.forEach(f => { x.globalAlpha = Math.max(0, f.a); L(f.t, f.x, f.y); }); x.globalAlpha = 1;
    if (g.storm) { x.fillStyle = 'rgba(20,18,58,.5)'; x.fillRect(0, 0, W, H); }
    x.fillStyle = '#fff'; const sp = g.storm ? 3 : 1;
    for (const f of this.flakes) { f.y = (f.y + f.s * .02 * sp) % H; f.x = (f.x + (g.storm ? 2.5 : .3) + W) % W; x.fillRect(f.x, f.y, 4, 4); }
    if (g.storm) L('Storm: cold drains twice as fast. Stay by a fire.', W / 2, 490, '#ffb347');
  }
}
