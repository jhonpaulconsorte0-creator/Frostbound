/* Game controller: world setup, input, main loop, interactions, HUD and overlays. */
class Game {
  constructor() {
    this.cv = document.getElementById('cv'); this.r = new Renderer(this.cv.getContext('2d'));
    this.keys = {}; this.running = false; this.over = false; this.p = new Player();
    this.res = []; this.fires = []; this.wolves = []; this.fx = []; this.dummy = null; this.tut = null;
    this.t = 0; this.msgT = 0; this.storm = false; this.last = 0; this.cardStep = -1;
    this.buildUI(); this.bindInput(); this.showTitle();
    requestAnimationFrame(t => this.loop(t));
  }
  $(id) { return document.getElementById(id); }
  buildUI() {
    this.$('bars').innerHTML = METERS.map(([k, n, c]) => `<div class="m"><small><span>${n}</span><span id="v_${k}"></span></small><div class="bar"><i id="b_${k}" style="background:${c}"></i></div></div>`).join('');
    this.$('cr').innerHTML = Object.entries(CFG.RECIPES).map(([k, r]) => `<button class="btn" data-k="${k}">${r.name}<small>${Object.entries(r.cost).map(([a, b]) => b + ' ' + a).join(' + ')}</small></button>`).join('');
    this.$('cr').querySelectorAll('button').forEach(b => b.onclick = () => this.craft(b.dataset.k));
    this.$('eat').onclick = () => this.eat(); this.$('drink').onclick = () => this.drink();
  }
  bindInput() {
    addEventListener('keydown', e => {
      const k = e.key.toLowerCase(); this.keys[k] = 1;
      if (!this.running || this.over) return;
      if (k === 'q') this.eat(); if (k === 'r') this.drink();
      if ([' ', 'arrowup', 'arrowdown', 'arrowleft', 'arrowright'].includes(k)) e.preventDefault();
    });
    addEventListener('keyup', e => { this.keys[e.key.toLowerCase()] = 0; });
  }
  makeWorld() {
    const L = (k, n, a) => a.map(([x, y]) => new Resource(k, x, y, n));
    return [...L('tree', 6, [[140, 380]]), ...L('tree', 5, [[210, 300], [330, 200], [480, 330], [600, 420], [120, 150], [420, 90], [560, 200]]),
      ...L('rock', 4, [[200, 450], [390, 360], [520, 130], [680, 300], [250, 120]]), ...L('bush', 3, [[300, 330], [100, 260], [620, 330], [460, 230]]),
      ...L('ice', 5, [[60, 60], [700, 450], [350, 470], [250, 40]])];
  }
  start(withTutorial) {
    this.p = withTutorial ? new Player(55, 60, 60) : new Player(70, 75, 75);
    this.res = this.makeWorld(); this.fires = []; this.wolves = []; this.fx = []; this.t = 0; this.lastSpawn = 0;
    this.ate = false; this.drank = false; this.over = false; this.running = true; this.storm = false; this.cardStep = -1;
    this.dummy = withTutorial ? new Dummy(330, 440) : null; this.tut = withTutorial ? new Tutorial(this) : null;
    if (!withTutorial) this.spawnWolves(2);
    this.$('ov').style.display = 'none';
  }
  spawnWolves(n) { for (let i = 0; i < n; i++) this.wolves.push(new Wolf(380 + Math.random() * 340, 40 + Math.random() * 300)); }
  finishTutorial() { this.tut = null; this.t = 0; this.spawnWolves(2); }
  toast(text) { this.msgT = 3; const e = this.$('toast'); e.textContent = text; e.style.opacity = 1; }
  float(x, y, t) { this.fx.push({ x, y, t, a: 1 }); }
  hurtPlayer(d) { this.p.hp -= d; this.p.hurt = .2; this.float(this.p.x, this.p.y - 18, '-' + d); }
  craft(key) {
    if (!this.running || this.over) return;
    const p = this.p, rc = CFG.RECIPES[key];
    if (key !== 'fire' && p.inv.gear[key]) return this.toast('You already have a ' + rc.name + '.');
    const r = p.inv.craft(key);
    if (!r.ok) return this.toast('Cannot craft ' + rc.name + '. Need ' + r.missing.map(([a, n]) => n + ' more ' + a).join(', ') + '.');
    if (key === 'fire') this.fires.push({ x: p.x, y: p.y, t: 120 }); else p.inv.gear[key] = true;
    this.toast('Crafted ' + rc.name + '!');
  }
  eat() { const p = this.p; if (!this.running || this.over) return; if (p.inv.use('berries')) { p.hunger = Math.min(100, p.hunger + 25); this.ate = true; this.float(p.x, p.y - 18, '+25 hunger'); } else this.toast('No berries. Pick some from a bush with E.'); }
  drink() { const p = this.p; if (!this.running || this.over) return; if (p.inv.use('ice')) { p.thirst = Math.min(100, p.thirst + 25); this.drank = true; this.float(p.x, p.y - 18, '+25 thirst'); } else this.toast('No ice. Chip some from blue ice with E.'); }
  interact() {
    const p = this.p;
    if (p.dist(CFG.BEACON) < 55) return p.inv.gear.flare ? this.end(true, 'Rescued!', 'Your flare lit the ridge and the rescue helicopter answers. You survived the Kaltvik ice shelf.') : this.toast('The beacon needs a Signal flare. Craft one first.');
    const e = this.res.filter(r => r.left > 0 && p.dist(r) < CFG.REACH).sort((a, b) => p.dist(a) - p.dist(b))[0];
    if (!e) return this.toast('Nothing in reach. Walk up to a tree, rock, bush or blue ice.');
    if (p.stamina < 3) return this.toast('Too tired to work. Stop and let stamina recover.');
    if (!p.inv.add(e.item, 1)) return this.toast('Pack full (' + CFG.CAP + ' max ' + e.item + '). Use or craft something first.');
    e.left--; p.stamina -= 3; this.float(e.x, e.y - 16, '+1 ' + e.item);
  }
  attack() {
    const p = this.p, t = [...this.wolves, this.dummy].filter(o => o && o.hp > 0 && p.dist(o) < 56).sort((a, b) => p.dist(a) - p.dist(b))[0];
    if (!t) return this.float(p.x, p.y - 18, 'miss');
    const d = Combat.damage(p.weaponDamage, t.armor); t.hp -= d; t.flash = .15; this.float(t.x, t.y - 18, '-' + d);
    if (t.hp <= 0 && t.isWolf) { p.inv.add('hide', 2); this.toast('Wolf down! +2 hide'); }
  }
  update(dt) {
    const p = this.p, k = this.keys; this.t += dt;
    const nearFire = this.fires.some(f => p.dist(f) < 90); this.storm = !this.tut && this.t % 70 > 50;
    p.update(dt, k, nearFire, this.storm);
    if (k.e && p.gatherCd.ready(this.t)) { p.gatherCd.trigger(this.t); this.interact(); }
    if (k[' '] && p.attackCd.ready(this.t)) { p.attackCd.trigger(this.t); this.attack(); }
    this.wolves.forEach(w => w.update(dt, p, this)); this.wolves = this.wolves.filter(w => w.hp > 0);
    if (this.dummy) this.dummy.flash = Math.max(0, this.dummy.flash - dt);
    if (!this.tut && this.wolves.length < 3 && this.t - this.lastSpawn > 40) { this.lastSpawn = this.t; this.spawnWolves(1); }
    this.fires.forEach(f => f.t -= dt); this.fires = this.fires.filter(f => f.t > 0);
    this.fx.forEach(f => { f.y -= 20 * dt; f.a -= dt; }); this.fx = this.fx.filter(f => f.a > 0);
    if (this.msgT > 0 && (this.msgT -= dt) <= 0) this.$('toast').style.opacity = 0;
    if (this.tut) this.tut.update(dt);
    if (p.hp <= 0) this.end(false, 'You did not survive',
      p.warmth <= 0 ? 'The cold took you. Stay near a campfire and craft a fur coat.' : p.hunger <= 0 ? 'You starved. Pick berries and eat before Hunger hits zero.' :
      p.thirst <= 0 ? 'Dehydration got you. Chip ice and melt it often.' : 'The wolves overwhelmed you. Craft a spear and fight one at a time.');
  }
  hud() {
    const p = this.p, i = p.inv, g = i.gear;
    for (const [k] of METERS) { const v = Math.max(0, Math.round(p[k])); this.$('b_' + k).style.width = v + '%'; this.$('v_' + k).textContent = v; }
    this.$('inv').innerHTML = ['wood', 'stone', 'berries', 'ice', 'hide'].map(r => `<span>${r}: <b>${i.count(r)}</b></span>`).join('') + (g.spear ? '<span>spear</span>' : '') + (g.coat ? '<span>coat</span>' : '') + (g.flare ? '<span>flare</span>' : '');
    const hl = this.tut ? this.tut.step.hl() : '';
    document.querySelectorAll('[data-k]').forEach(b => { const k = b.dataset.k; b.classList.toggle('hl', k === hl); if (CFG.RECIPES[k]) b.disabled = !!(g[k] && k !== 'fire'); });
    this.$('eat').disabled = !i.count('berries'); this.$('drink').disabled = !i.count('ice');
    const tc = this.$('tc');
    if (this.tut && this.tut.i < this.tut.steps.length) {
      tc.style.display = 'block';
      if (this.cardStep !== this.tut.i) {
        this.cardStep = this.tut.i; const s = this.tut.step;
        tc.innerHTML = `<button class="btn">Skip</button><b>Step ${this.tut.i + 1} of ${this.tut.steps.length} · ${s.title}</b><br>${s.text}`;
        tc.querySelector('button').onclick = () => { this.finishTutorial(); this.toast('Tutorial skipped. Survive!'); };
      }
    } else { tc.style.display = 'none'; this.cardStep = -1; }
  }
  overlay(html) { const o = this.$('ov'); o.style.display = 'flex'; o.innerHTML = html; }
  showTitle() {
    this.overlay(`<h1>Frostbound</h1><p>Mara Voss, a polar surveyor, survives a plane crash on the Kaltvik ice shelf. The radio is dead. A rescue beacon stands on the north-east ridge, but it only answers a signal flare. Wolves are tracking her scent and a storm is coming.</p><p>Gather wood, stone, berries and ice. Craft a fire, spear, coat and flare. Light the beacon.</p><div class="row"><button class="btn pri" id="s1">Start with tutorial</button><button class="btn" id="s2">Skip to survival</button></div>`);
    this.$('s1').onclick = () => this.start(true); this.$('s2').onclick = () => this.start(false);
  }
  end(win, title, msg) {
    this.over = true;
    this.overlay(`<h1>${title}</h1><p>${msg}</p><div class="row"><button class="btn pri" id="s2">Play again</button><button class="btn" id="s1">Replay tutorial</button></div>`);
    this.$('s1').onclick = () => this.start(true); this.$('s2').onclick = () => this.start(false);
  }
  loop(t) {
    const dt = Math.min(.05, (t - this.last) / 1000); this.last = t;
    if (this.running && !this.over) this.update(dt);
    if (this.running) this.hud();
    this.r.draw(this, t); requestAnimationFrame(n => this.loop(n));
  }
}
