/* Entry point: starts the game and wires the Play / QA tabs. */
const game = new Game();
const showTab = n => {
  document.getElementById('play').hidden = n !== 1; document.getElementById('qa').hidden = n !== 2;
  document.getElementById('t1').className = n === 1 ? 'on' : ''; document.getElementById('t2').className = n === 2 ? 'on' : '';
  if (n === 2) QA.run(document.getElementById('tt'), document.getElementById('sum'));
};
document.getElementById('t1').onclick = () => showTab(1); document.getElementById('t2').onclick = () => showTab(2);
document.getElementById('run').onclick = () => QA.run(document.getElementById('tt'), document.getElementById('sum'));
